# packer build -var-file=vars.json build.json
