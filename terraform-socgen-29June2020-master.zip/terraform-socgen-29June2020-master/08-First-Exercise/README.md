# First Exercise

## Provision the infrastructure to meet the following conditions:

 1. Create 4 Instance each in 2 Regions & print the output of Public & Private IP address
 2. Only 1 Frontend & 1 Backend instance in a single avaliablity zone. 
 3. if updated, the new Frontend server must be up & running before we delete the old ones
 4. The backend severs can't be delete or changed with terraform apply. 




